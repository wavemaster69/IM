INSERT INTO `order_status` (`id`, `name`, `slug`, `serial`, `color`, `created_at`, `updated_at`) VALUES
(1, 'Confirmed', 'confirmed', 1, '#0d9965', '2022-02-02 21:08:20', '2022-02-22 03:46:30'),
(2, 'On hold', 'on-hold', 2, '#64acd8', '2022-02-19 16:37:55', '2022-02-19 16:37:55'),
(3, 'Processing', 'processing' , 3, '#eacb34', '2022-02-23 14:55:01', '2022-02-23 14:55:01');
