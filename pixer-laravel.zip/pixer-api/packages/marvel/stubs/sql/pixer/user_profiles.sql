INSERT INTO `user_profiles` (`id`, `avatar`, `bio`, `socials`, `contact`, `customer_id`, `created_at`, `updated_at`) VALUES
(1, '{\"id\": 460, \"original\": \"https://pixarlaravel.s3.ap-southeast-1.amazonaws.com/459/mask.png\", \"thumbnail\": \"https://pixarlaravel.s3.ap-southeast-1.amazonaws.com/459/conversions/mask-thumbnail.jpg\"}', NULL, NULL, NULL, 1, '2022-01-30 06:59:51', '2022-02-16 08:30:28'),
(2, NULL, '', NULL, '19365141641631', 3, '2021-08-18 13:17:53', '2021-08-18 13:17:53');
