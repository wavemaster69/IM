INSERT INTO `types` (`id`, `name`, `settings`, `slug`, `icon`, `promotional_sliders`, `created_at`, `updated_at`) VALUES
(1, 'Fixed', '{\"isHome\": false, \"layoutType\": \"classic\", \"productCard\": \"helium\"}', 'fixed', 'FixedIcon', '[]', '2022-01-22 13:04:37', '2022-02-02 18:35:29'),
(2, 'Liquid', '{\"isHome\": false, \"layoutType\": \"classic\", \"productCard\": \"helium\"}', 'liquid', 'LiquidIcon', '[]', '2022-01-22 13:05:05', '2022-02-02 18:35:15'),
(3, 'Responsive', '{\"isHome\": false, \"layoutType\": \"classic\", \"productCard\": \"helium\"}', 'responsive', 'ResponsiveIcon', '[]', '2022-01-22 13:05:32', '2022-02-02 18:35:03'),
(4, 'N/A', '{\"isHome\": false, \"layoutType\": \"classic\", \"productCard\": \"helium\"}', 'n-a', 'NoTypeIcon', '[]', '2022-01-22 13:05:52', '2022-02-02 18:34:55');
