INSERT INTO `model_has_permissions` (`permission_id`, `model_type`, `model_id`) VALUES
(2, 'Marvel\\Database\\Models\\User', 1),
(2, 'Marvel\\Database\\Models\\User', 3),
(2, 'Marvel\\Database\\Models\\User', 5),
(2, 'Marvel\\Database\\Models\\User', 6),
(3, 'Marvel\\Database\\Models\\User', 1);